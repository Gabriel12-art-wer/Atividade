import { useState } from 'react'
import './compras.css'

const Compras = () =>{

const [itens, setItens]= useState(['Arroz', 'Feijão','Carne'])
const [coisa, setcoisa] = useState('');

const adicionar = () => {
    const handlecoisa = (event) =>{
        setcoisa(event.target.value)
        
    }
    //jeito errado
    //itens.push(item)
    //setItens(itens)

    setItens((itens) =>{
        return [...itens, handlecoisa]
    }) 
}

    const remover = () =>{
        const handlecoisa = (event) =>{
            setcoisa(event.target.value)
            
        }
        const removivel = handlecoisa
        {itens.map((item,indice) => { return })}


    }

return (
    <section className= "compras"><h1>Compras</h1>
    <input type="string" onChange={handlecoisa} value={coisa}/>
    <button onClick={adicionar}>Adicionar</button>
    <button onClick={remover}>Remover</button>
    <ol>
     {itens.map((item,indice) => { return <li  key={indice}>{item}</li>})}

    </ol>
    
    </section>
)



  
}

export default Compras