import { Links,Link } from "react-router-dom";
import "./Home.css"

export default function Home(){
    return(
        <>
        <h1>Home</h1>
        <ul>
        <li><Link to="/imc">IMC</Link></li>
        <li><Link to="/Calculadora">Calculadora</Link></li>
        <li><Link to="/Compras">Compras</Link></li>
        </ul>
        </>
    )
}