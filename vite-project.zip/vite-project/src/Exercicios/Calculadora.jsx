import { useState } from "react";

export default function Calculadora(){


let [Valor1, setValor1] = useState('');
let [Valor2, setValor2] = useState('');
let [message, setMessage] = useState('');


const handleValor1 = (event) =>{
    setValor1(event.target.value)
    
}

const handleValor2 = (event) =>{
    setValor2(event.target.value)
   
}

const Adicao = (event) =>{
    console.log(event)
    alert(message = Valor1 + Valor2)

}

const Subtracao = (event) =>{
    console.log(event)
    alert(message = Valor1 - Valor2)
}

const Multiplicacao = (event) =>{
    console.log(event)
    alert(message = Valor1 * Valor2)
}

const Divicao = (event) =>{
    console.log(event)
    alert(message = Valor1 / Valor2)
}
const handleClear = (event) => {
    setValor1(0)
    setValor2(0)
}

return(<section>

    <input type="number" onChange={handleValor1} value={Valor1}/>
    <input type="number" onChange={handleValor2} value={Valor2}/>
    
    <button onClick={Adicao}>Somar</button>
    <button onClick={Subtracao}>Diminuir</button>
    <button onClick={Divicao}>Dividir</button>
    <button onClick={Multiplicacao}>multiplicar</button>
    <button onClick={handleClear}>Limpar</button>
    {<p>{message}</p>}
    
    </section>)
}