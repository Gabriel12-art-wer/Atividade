import { useState } from 'react'
import "./imc.css"

export default function Imc() {

    const [resultado, setresultado] = useState('');
    const [peso, setpeso] = useState('');
    const [altura, setaltura] = useState('');
    const [classificacao, setclassificacao] = useState('');



    function Calcular() {
        const pesoNun = parseFloat(peso)
        const alturaNun = parseFloat(altura)
        const imc = pesoNun / Math.pow(alturaNun, 2)
        

        setresultado(
            new Intl.NumberFormat({ language: 'pt-BR' }).format(
            imc.toFixed(2)
            )
        )
        
        let classificacao = ''
        if(imc <16){
            classificacao = 'magreza grave'
        }
        else if(imc >=16 && imc < 17){
            classificacao = 'magreza moerada'
        }
        else if(imc >=17 && imc < 18.5){
            classificacao = 'magreza leve'
        }
        else if(imc >=18.5 && imc < 25){
            classificacao = 'saldavel'
        }
        else if(imc >=25 && imc < 30){
            classificacao = 'sobrepeso'
        }
        else if(imc >=30 && imc < 35){
            classificacao = 'obesidade grau I'
        }                               
        else if(imc >=35 && imc < 40){
            classificacao = 'obesidade grau II'
        } else {classificacao = 'obesidade grau III'}
        setclassificacao(classificacao)
    }

    function limPar() {
    setpeso('')
    setaltura('')
    setclassificacao('')
    setresultado('')
    }



    return (<section className='imc'>
        <h1>IMC - Indice de Masa Corpória</h1>
        <input onChange={(e) => setpeso(e.target.value)} placeholder="Peso" type="text" />
        <input onChange={(e) => setaltura(e.target.value)} placeholder="Altura" type="text" />
        
        <div class="imc-action">
            <button>Calcular</button>
            <button>Limpar</button>
        </div>

        <button onClick={Calcular}>Calcular</button>
        <button onClick={limPar}>Limpar</button>

        <div>
        {resultado && <p>IMC: {resultado} / Classificação: {classificacao}</p>}        
        </div>
    </section>)
}


