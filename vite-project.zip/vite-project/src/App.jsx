import './App.css'
import HelloWorld from './hello-word/HelloWord'
import Calculadora from './Exercicios/Calculadora'
import { BrawserRouter, Route, Routes } from 'react-router-dom'
import Imc from './Exercicios/Imc'
import Compras from './compras'

function App() {
  

  return (
    <BrawserRouter>
    <Routes>
    <Route index element={<Home />} />
     <Route path= "/HelloWorld" element={<HelloWorld/>} />
     <Route path= "/imc" element={<Imc/>} />
     <Route path= "/Calculadora" element={<Calculadora/>} />
     <Route path="/Compras" element={<Compras />} />
    </Routes>
    </BrawserRouter>
  )
}

export default App
